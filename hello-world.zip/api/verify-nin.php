<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get authorization header
$headers = getallheaders();
$authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : '';

if (!$authHeader || !preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authorization token required']);
    exit;
}

$token = $matches[1];

// Verify token (simplified)
try {
    $tokenData = json_decode(base64_decode($token), true);
    if (!$tokenData || $tokenData['exp'] < time()) {
        throw new Exception('Invalid or expired token');
    }
    $userId = $tokenData['user_id'];
} catch (Exception $e) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['nin']) || !isset($input['phone'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'NIN and phone number are required']);
    exit;
}

$nin = preg_replace('/\D/', '', $input['nin']);
$phone = preg_replace('/\D/', '', $input['phone']);

// Validation
if (strlen($nin) !== 11) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'NIN must be 11 digits']);
    exit;
}

if (strlen($phone) < 10) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid phone number']);
    exit;
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    // Log verification attempt
    $logQuery = "INSERT INTO verification_logs (user_id, nin, phone, status, created_at) VALUES (?, ?, ?, 'pending', NOW())";
    $logStmt = $db->prepare($logQuery);
    $logStmt->execute([$userId, $nin, $phone]);
    $logId = $db->lastInsertId();
    
    // Simulate NIN verification (replace with actual API call)
    $verificationResult = simulateNINVerification($nin, $phone);
    
    if ($verificationResult['success']) {
        // Update log status
        $updateLogQuery = "UPDATE verification_logs SET status = 'success', response_data = ? WHERE id = ?";
        $updateLogStmt = $db->prepare($updateLogQuery);
        $updateLogStmt->execute([json_encode($verificationResult['data']), $logId]);
        
        // Store verification result
        $resultQuery = "INSERT INTO verification_results (user_id, nin, phone, name, status, verified_at) VALUES (?, ?, ?, ?, 'verified', NOW())";
        $resultStmt = $db->prepare($resultQuery);
        $resultStmt->execute([$userId, $nin, $phone, $verificationResult['data']['name']]);
        
        echo json_encode([
            'success' => true,
            'message' => 'NIN verification successful',
            'data' => $verificationResult['data']
        ]);
    } else {
        // Update log status
        $updateLogQuery = "UPDATE verification_logs SET status = 'failed', error_message = ? WHERE id = ?";
        $updateLogStmt = $db->prepare($updateLogQuery);
        $updateLogStmt->execute([$verificationResult['message'], $logId]);
        
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => $verificationResult['message']
        ]);
    }
    
} catch (PDOException $e) {
    error_log("Verification error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error occurred']);
} catch (Exception $e) {
    error_log("Verification error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Verification service error']);
}

function simulateNINVerification($nin, $phone) {
    // Simulate API delay
    usleep(500000); // 0.5 seconds
    
    // Mock data for demonstration
    $mockData = [
        '12345678901' => [
            'name' => 'John Doe',
            'phone' => '+2348012345678',
            'status' => 'Active',
            'date_of_birth' => '1990-01-01',
            'gender' => 'Male'
        ],
        '98765432109' => [
            'name' => 'Jane Smith',
            'phone' => '+2348098765432',
            'status' => 'Active',
            'date_of_birth' => '1985-05-15',
            'gender' => 'Female'
        ]
    ];
    
    if (isset($mockData[$nin])) {
        return [
            'success' => true,
            'data' => $mockData[$nin]
        ];
    } else {
        return [
            'success' => false,
            'message' => 'NIN not found or invalid'
        ];
    }
}
?>
