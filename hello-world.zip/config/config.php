<?php
// Application Configuration
define('APP_NAME', 'Robost Tech');
define('APP_VERSION', '1.0.0');
define('APP_ENV', 'development'); // development, staging, production

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'robost_tech');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// API Configuration
define('API_VERSION', 'v1');
define('API_RATE_LIMIT', 100); // requests per minute
define('API_TIMEOUT', 30); // seconds

// Security Configuration
define('JWT_SECRET', 'your-secret-key-here-change-in-production');
define('JWT_EXPIRY', 24 * 60 * 60); // 24 hours
define('PASSWORD_MIN_LENGTH', 6);
define('MAX_LOGIN_ATTEMPTS', 5);

// NIN Verification Configuration
define('NIN_API_URL', 'https://api.nimc.gov.ng/verify'); // Replace with actual API
define('NIN_API_KEY', 'your-nin-api-key-here');
define('NIN_TIMEOUT', 30);
define('MAX_DAILY_VERIFICATIONS', 500);

// Email Configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-app-password');
define('FROM_EMAIL', 'noreply@robosttech.com');
define('FROM_NAME', 'Robost Tech');

// File Upload Configuration
define('UPLOAD_MAX_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_FILE_TYPES', ['jpg', 'jpeg', 'png', 'pdf']);
define('UPLOAD_PATH', '../uploads/');

// Logging Configuration
define('LOG_LEVEL', 'INFO'); // DEBUG, INFO, WARNING, ERROR
define('LOG_PATH', '../logs/');
define('LOG_MAX_FILES', 30);

// Cache Configuration
define('CACHE_ENABLED', true);
define('CACHE_TTL', 3600); // 1 hour
define('CACHE_PREFIX', 'robost_');

// Error Reporting
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Timezone
date_default_timezone_set('Africa/Lagos');

// Session Configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_strict_mode', 1);

// CORS Headers
function setCorsHeaders() {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit;
    }
}

// Error Handler
function customErrorHandler($errno, $errstr, $errfile, $errline) {
    $error = [
        'type' => 'PHP Error',
        'message' => $errstr,
        'file' => $errfile,
        'line' => $errline,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    error_log(json_encode($error), 3, LOG_PATH . 'errors.log');
    
    if (APP_ENV === 'production') {
        return true; // Don't display errors in production
    }
    
    return false; // Display errors in development
}

set_error_handler('customErrorHandler');

// Exception Handler
function customExceptionHandler($exception) {
    $error = [
        'type' => 'Uncaught Exception',
        'message' => $exception->getMessage(),
        'file' => $exception->getFile(),
        'line' => $exception->getLine(),
        'trace' => $exception->getTraceAsString(),
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    error_log(json_encode($error), 3, LOG_PATH . 'exceptions.log');
    
    if (APP_ENV === 'production') {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Internal server error']);
    } else {
        echo '<pre>' . print_r($error, true) . '</pre>';
    }
}

set_exception_handler('customExceptionHandler');

// Create necessary directories
$directories = [LOG_PATH, UPLOAD_PATH, '../cache/'];
foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}
?>
